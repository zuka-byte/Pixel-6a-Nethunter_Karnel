#!/system/bin/sh
# bluejay-kali_nethunter — Magisk boot trigger
# Calls the vendor binary which handles all HID setup logic
exec /vendor/bin/bluejay-kali_nethunter-hid
