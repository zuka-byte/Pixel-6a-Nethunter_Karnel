#!/system/bin/sh
# NetHunter HID Gadget Setup
# Runs on every boot after sys.boot_completed=1
# Creates /dev/hidg0 for USB HID keyboard attacks

GADGET=/config/usb_gadget/g1
LOG=/data/local/tmp/nethunter-hid.log
UDC_NAME=11110000.dwc3

log() {
    echo "[$(date '+%H:%M:%S')] $*" >> "$LOG"
}

# Fresh log each boot
echo "=== NetHunter HID Boot $(date) ===" > "$LOG"

# Wait for USB gadget configfs to be available
wait=0
while [ ! -d "$GADGET/functions" ] && [ $wait -lt 30 ]; do
    sleep 1
    wait=$((wait + 1))
done

if [ ! -d "$GADGET/functions" ]; then
    log "ERROR: USB gadget not found after 30s"
    exit 1
fi

log "USB gadget found"

# Wait for UDC to be bound (HAL has finished initial setup)
wait=0
while [ $wait -lt 30 ]; do
    UDC=$(cat "$GADGET/UDC" 2>/dev/null)
    [ -n "$UDC" ] && break
    sleep 1
    wait=$((wait + 1))
done

if [ -z "$UDC" ]; then
    log "ERROR: UDC never bound, using default $UDC_NAME"
    UDC=$UDC_NAME
else
    log "UDC bound: $UDC"
fi

# Check if HID already linked (idempotent)
if [ -L "$GADGET/configs/b.1/hid.usb0" ]; then
    log "HID already linked — checking /dev/hidg0"
    if [ -c /dev/hidg0 ]; then
        log "SUCCESS: /dev/hidg0 already present"
        chmod 0666 /dev/hidg0
        exit 0
    fi
    log "HID linked but /dev/hidg0 missing, continuing setup"
fi

# Create HID function directory if needed
if [ ! -d "$GADGET/functions/hid.usb0" ]; then
    mkdir -p "$GADGET/functions/hid.usb0"
    log "Created hid.usb0 function dir"
fi

# Configure HID as a boot keyboard
# protocol=1 (keyboard), subclass=1 (boot interface), report_length=8
echo 1 > "$GADGET/functions/hid.usb0/protocol"
echo 1 > "$GADGET/functions/hid.usb0/subclass"
echo 8 > "$GADGET/functions/hid.usb0/report_length"

# Write standard boot keyboard HID report descriptor (63 bytes)
# Modifier keys (1 byte) + Reserved (1 byte) + Keycodes (6 bytes) = 8 bytes per report
printf '\x05\x01\x09\x06\xa1\x01\x05\x07\x19\xe0\x29\xe7\x15\x00\x25\x01\x75\x01\x95\x08\x81\x02\x95\x01\x75\x08\x81\x03\x95\x05\x75\x01\x05\x08\x19\x01\x29\x05\x91\x02\x95\x01\x75\x03\x91\x03\x95\x06\x75\x08\x15\x00\x25\x65\x05\x07\x19\x00\x29\x65\x81\x00\xc0' \
    > "$GADGET/functions/hid.usb0/report_desc"

log "HID function configured (keyboard)"

# Stop USB HAL so it doesn't rebind UDC during our window
# Uses init control socket — safe from root shell
setprop ctl.stop vendor.usb-gadget-hal
log "Stopped vendor.usb-gadget-hal"
sleep 0.8

# Unbind UDC — USB disconnects here (ADB drops but script continues locally)
echo "" > "$GADGET/UDC"
log "UDC unbound"
sleep 0.3

# Link HID function into the active config
# This requires UDC to be unbound (kernel enforces this)
ln -s "$GADGET/functions/hid.usb0" "$GADGET/configs/b.1/hid.usb0" 2>&1 | tee -a "$LOG"
log "ln exit code: $?"

# Rebind UDC — USB reconnects with ADB + HID composite device
echo "$UDC" > "$GADGET/UDC"
log "UDC rebound: $UDC"

# Give USB time to enumerate
sleep 2

# Verify /dev/hidg0
if [ -c /dev/hidg0 ]; then
    chmod 0666 /dev/hidg0
    log "SUCCESS: /dev/hidg0 created ($(ls -la /dev/hidg0))"
else
    log "WARNING: /dev/hidg0 not found — check dmesg"
fi

# Do NOT restart vendor.usb-gadget-hal
# The current config (ADB + HID) persists as long as HAL stays stopped.
# USB mode switching (MTP, etc.) won't work until HAL restarts or device reboots.
# On reboot this script runs again and re-establishes HID.

log "=== NetHunter HID setup complete ==="
